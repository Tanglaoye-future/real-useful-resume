# 实习僧数据分析作业包（internship_data_analysis_homework）

## 目录结构
- `data/raw/`：原始数据（CSV/Excel）
- `data/clean/`：清洗后数据（CSV）
- `notebooks/internship_analysis.ipynb`：主 Notebook（可一键运行）
- `reports/internship_analysis.html`：导出的分析报告（HTML）
- `assets/figures/`：可选图表文件输出目录
- `src/`：可选脚本与工具函数（当前主要逻辑在 Notebook 内）

## 环境与依赖
安装：`pip install -r requirements.txt`

依赖：requests、beautifulsoup4、pandas、numpy、matplotlib、seaborn、tqdm、python-dateutil、jupyter、nbconvert、requests-html。

## 运行步骤
1. 进入作业包根目录。
2. 执行 Notebook：
   - 交互运行：`jupyter notebook` 打开 `notebooks/internship_analysis.ipynb` 自上而下运行。
   - 一键执行与导出：`jupyter nbconvert --to notebook --execute notebooks/internship_analysis.ipynb --output notebooks/internship_analysis_executed.ipynb && jupyter nbconvert notebooks/internship_analysis.ipynb --to html --output-dir reports`
3. 输出文件：`data/clean/internships_clean.csv`、`reports/internship_analysis.html`。

## 作业要求对照
- 数据获取：含 Cookie 预热与动态渲染回退（必要时），节流与异常处理。
- 数据清洗：缺失值/重复处理、薪资单位统一、地点/学历/经验标准化。
- 数据分析与可视化：分维度统计，直方图、饼图、条形图、箱线图，上海本科专项分析。
- 报告生成：Notebook 含 Markdown 说明，并导出 HTML 报告。

## 跨设备运行
1. 压缩为 `internship_data_analysis_homework.zip` 后复制到另一设备。
2. 安装依赖并按“运行步骤”执行。
3. 如站点访问受限导致抓取为空，Notebook 会使用示例原始数据继续清洗与分析，保证可运行性。

