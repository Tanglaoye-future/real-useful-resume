#!/usr/bin/env bash
set -euo pipefail

echo "Installing dependencies..."
pip install -r requirements.txt

echo "Executing notebook..."
jupyter nbconvert --to notebook --execute notebooks/internship_analysis.ipynb --output notebooks/internship_analysis_executed.ipynb

echo "Exporting HTML report..."
jupyter nbconvert notebooks/internship_analysis.ipynb --to html --output-dir reports

echo "Done. Outputs in data/clean and reports/."
