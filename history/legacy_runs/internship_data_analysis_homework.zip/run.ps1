param(
    [switch]$ExportHtml
)

Write-Host "Installing dependencies..."
pip install -r requirements.txt

Write-Host "Executing notebook..."
jupyter nbconvert --to notebook --execute notebooks/internship_analysis.ipynb --output notebooks/internship_analysis_executed.ipynb

if ($ExportHtml) {
  Write-Host "Exporting HTML report..."
  jupyter nbconvert notebooks/internship_analysis.ipynb --to html --output-dir reports
}

Write-Host "Done. Outputs in data/clean and reports/."
